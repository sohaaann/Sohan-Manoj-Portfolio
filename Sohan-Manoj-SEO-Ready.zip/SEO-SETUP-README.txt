# Sohan Manoj Portfolio — SEO update

This version adds:
- Canonical URL for https://sohanmanoj.vercel.app/
- Search-friendly title and description
- Open Graph and social sharing metadata
- Schema.org Person, ProfilePage, and WebSite structured data
- robots.txt and sitemap.xml
- Updates to two stale links pointing to old portfolio URLs

## Publish the changes
1. Open the GitHub repository connected to the Vercel project.
2. Replace/add the files from this ZIP in the project root, preserving the `assets/` folder.
3. Commit and push the changes to the production branch. Vercel should deploy automatically if Git integration is enabled.
4. Check these URLs after deployment:
   - https://sohanmanoj.vercel.app/
   - https://sohanmanoj.vercel.app/robots.txt
   - https://sohanmanoj.vercel.app/sitemap.xml
5. In Google Search Console, add the URL-prefix property `https://sohanmanoj.vercel.app/`, verify ownership, inspect the homepage, and request indexing.

Important:
- Structured data helps search engines interpret the page; it does not guarantee a Knowledge Panel or a first-place result.
- Review all personal/contact information and credentials before publishing; this ZIP preserves the existing portfolio content.
- After deployment, submit the sitemap in Search Console.
