const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

const terminalLines = [
  "$ init --portfolio sohan-manoj",
  "> scanning disciplines: computer science, economics, psychology",
  "> loading systems: AI fundamentals, SQL, Power BI, market research",
  "> active research: consumer behavior + decision intelligence",
  "> status: open for internships, collaborations, analytics roles"
];

const portfolioCommands = [
  "analyze --consumer-behavior",
  "model --human-centered-ai",
  "visualize --market-trends",
  "synthesize --research-findings"
];

const caseDeck = [
  {
    kicker: "Case 01",
    title: "Consumer Insight Engine",
    text: "Survey-led consumer behavior analysis transformed into trend maps, segments, and strategy signals.",
    levels: ["82%", "64%", "91%", "58%"]
  },
  {
    kicker: "Case 02",
    title: "AI Analytics Lab",
    text: "Data interpretation, visualization, and machine-learning fundamentals shaped into human-centered AI explorations.",
    levels: ["74%", "88%", "69%", "93%"]
  },
  {
    kicker: "Case 03",
    title: "Decision Mirror",
    text: "Neuropsychology and behavioral economics lenses for understanding risk, value, incentives, and choice.",
    levels: ["92%", "71%", "84%", "77%"]
  },
  {
    kicker: "Case 04",
    title: "Market Systems Map",
    text: "Economic and business research connecting market structures, adoption patterns, and strategic recommendations.",
    levels: ["68%", "89%", "76%", "86%"]
  }
];

const modeMessages = {
  research: "Research mode online: evidence, surveys, and insight synthesis.",
  ai: "AI Systems mode: models, data flows, and human-centered intelligence.",
  behavior: "Behavior mode: decisions, cognition, risk, and consumer psychology.",
  market: "Markets mode: economics, trends, adoption, and strategy signals."
};

function setCompanionMessage(message) {
  const characterMessage = document.getElementById("characterMessage");
  const dockMessage = document.getElementById("dockMessage");
  if (characterMessage) characterMessage.textContent = message;
  if (dockMessage) dockMessage.textContent = message;
}

function setHeaderState() {
  const header = document.querySelector("[data-elevate]");
  if (!header) return;
  header.classList.toggle("is-elevated", window.scrollY > 24);
}

function setScrollProgress() {
  const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
  const percent = maxScroll > 0 ? (window.scrollY / maxScroll) * 100 : 0;
  document.documentElement.style.setProperty("--scroll", `${percent}%`);
}

function initNavigation() {
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");
  if (!toggle || !nav) return;

  toggle.addEventListener("click", () => {
    const isOpen = toggle.getAttribute("aria-expanded") === "true";
    toggle.setAttribute("aria-expanded", String(!isOpen));
    nav.classList.toggle("is-open", !isOpen);
  });

  nav.addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof HTMLAnchorElement)) return;
    toggle.setAttribute("aria-expanded", "false");
    nav.classList.remove("is-open");
  });
}

function initReveals() {
  const elements = document.querySelectorAll(".reveal");
  if (!elements.length) return;

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      });
    },
    { threshold: 0.16 }
  );

  elements.forEach((element) => observer.observe(element));
}

function initCounters() {
  const counters = document.querySelectorAll("[data-count]");
  if (!counters.length) return;

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        const target = entry.target;
        const end = Number.parseFloat(target.dataset.count || "0");
        const isDecimal = String(target.dataset.count).includes(".");
        const duration = 1100;
        const startTime = performance.now();

        function tick(now) {
          const progress = Math.min((now - startTime) / duration, 1);
          const eased = 1 - Math.pow(1 - progress, 3);
          const value = end * eased;
          target.textContent = isDecimal ? value.toFixed(2) : String(Math.round(value));
          if (progress < 1) requestAnimationFrame(tick);
        }

        requestAnimationFrame(tick);
        observer.unobserve(target);
      });
    },
    { threshold: 0.5 }
  );

  counters.forEach((counter) => observer.observe(counter));
}

function initCursorGlow() {
  const glow = document.querySelector(".cursor-glow");
  if (!glow || prefersReducedMotion) return;

  let x = window.innerWidth * 0.5;
  let y = window.innerHeight * 0.35;
  let tx = x;
  let ty = y;

  window.addEventListener("pointermove", (event) => {
    tx = event.clientX;
    ty = event.clientY;
  });

  function animate() {
    x += (tx - x) * 0.11;
    y += (ty - y) * 0.11;
    glow.style.left = `${x}px`;
    glow.style.top = `${y}px`;
    requestAnimationFrame(animate);
  }

  animate();
}

function initTerminal() {
  const terminal = document.getElementById("terminalText");
  if (!terminal) return;

  if (prefersReducedMotion) {
    terminal.textContent = terminalLines.join("\n");
    return;
  }

  let lineIndex = 0;
  let charIndex = 0;
  let output = "";

  function type() {
    const line = terminalLines[lineIndex];
    output += line[charIndex] || "";
    terminal.textContent = `${output}_`;
    charIndex += 1;

    if (charIndex <= line.length) {
      window.setTimeout(type, 18);
      return;
    }

    output += "\n";
    charIndex = 0;
    lineIndex += 1;

    if (lineIndex < terminalLines.length) {
      window.setTimeout(type, 180);
    } else {
      cycleCommand();
    }
  }

  let commandIndex = 0;
  function cycleCommand() {
    window.setTimeout(() => {
      const lines = terminalLines.concat(`$ ${portfolioCommands[commandIndex]}`);
      terminal.textContent = `${lines.join("\n")}\n> ready_`;
      commandIndex = (commandIndex + 1) % portfolioCommands.length;
      cycleCommand();
    }, 1800);
  }

  type();
}

function initTilt() {
  if (prefersReducedMotion || window.matchMedia("(pointer: coarse)").matches) return;

  document.querySelectorAll(".tilt-card").forEach((card) => {
    card.addEventListener("pointermove", (event) => {
      const rect = card.getBoundingClientRect();
      const x = (event.clientX - rect.left) / rect.width - 0.5;
      const y = (event.clientY - rect.top) / rect.height - 0.5;
      card.style.transform = `perspective(900px) rotateX(${y * -7}deg) rotateY(${x * 8}deg) translateZ(0)`;
    });

    card.addEventListener("pointerleave", () => {
      card.style.transform = "";
    });
  });
}

function initMagneticButtons() {
  if (prefersReducedMotion || window.matchMedia("(pointer: coarse)").matches) return;

  document.querySelectorAll(".magnetic").forEach((button) => {
    button.addEventListener("pointermove", (event) => {
      const rect = button.getBoundingClientRect();
      const x = event.clientX - rect.left - rect.width / 2;
      const y = event.clientY - rect.top - rect.height / 2;
      button.style.transform = `translate(${x * 0.13}px, ${y * 0.18}px)`;
    });

    button.addEventListener("pointerleave", () => {
      button.style.transform = "";
    });
  });
}

function initExperienceModes() {
  const buttons = Array.from(document.querySelectorAll("[data-mode]"));
  if (!buttons.length) return;

  document.body.dataset.mode = "research";

  buttons.forEach((button) => {
    button.addEventListener("click", () => {
      const mode = button.dataset.mode || "research";
      document.body.dataset.mode = mode;
      buttons.forEach((item) => item.classList.toggle("active", item === button));
      setCompanionMessage(modeMessages[mode] || modeMessages.research);
    });
  });
}

function initCaseLab() {
  const buttons = Array.from(document.querySelectorAll("[data-case]"));
  const kicker = document.getElementById("caseKicker");
  const title = document.getElementById("caseTitle");
  const text = document.getElementById("caseText");
  const bars = Array.from(document.querySelectorAll(".signal-bars span"));
  const stage = document.getElementById("caseStage");
  if (!buttons.length || !kicker || !title || !text || !stage) return;

  function setCase(index) {
    const next = caseDeck[index] || caseDeck[0];
    kicker.textContent = next.kicker;
    title.textContent = next.title;
    text.textContent = next.text;
    bars.forEach((bar, barIndex) => {
      bar.style.setProperty("--level", next.levels[barIndex] || "70%");
    });
    buttons.forEach((button, buttonIndex) => {
      button.classList.toggle("active", buttonIndex === index);
    });
    setCompanionMessage(`${next.title}: ${next.text}`);
    stage.animate(
      [
        { transform: "perspective(1200px) rotateY(-6deg) translateY(10px)", opacity: 0.72 },
        { transform: "perspective(1200px) rotateY(0deg) translateY(0)", opacity: 1 }
      ],
      { duration: 420, easing: "cubic-bezier(.2,.8,.2,1)" }
    );
  }

  buttons.forEach((button) => {
    button.addEventListener("click", () => setCase(Number(button.dataset.case || 0)));
    button.addEventListener("pointerenter", () => {
      if (window.matchMedia("(pointer: fine)").matches) setCase(Number(button.dataset.case || 0));
    });
  });

  setCase(0);
}

function initCompanionDock() {
  const dock = document.querySelector(".companion-dock");
  const mini = document.getElementById("miniCompanion");
  if (!dock) return;

  function updateDock() {
    dock.classList.toggle("is-visible", window.scrollY > window.innerHeight * 0.52);
  }

  mini?.addEventListener("click", () => {
    document.getElementById("work-os")?.scrollIntoView({ behavior: "smooth", block: "start" });
    setCompanionMessage("Opening the immersive Work OS deck.");
  });

  window.addEventListener("scroll", updateDock, { passive: true });
  updateDock();
}

async function initThreeScene() {
  const canvas = document.getElementById("scene3d");
  if (!(canvas instanceof HTMLCanvasElement)) return;

  // A file opened directly in Chrome cannot reliably import remote ES modules.
  // The canvas fallback keeps the portfolio fully usable without a local server.
  if (window.location.protocol === "file:") {
    drawFallbackScene(canvas, prefersReducedMotion);
    return;
  }

  try {
    const THREE = await import("https://cdn.jsdelivr.net/npm/three@0.160.1/build/three.module.js");
    if (prefersReducedMotion) {
      drawFallbackScene(canvas, true);
      return;
    }

    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: true,
      preserveDrawingBuffer: true,
      powerPreference: "high-performance"
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.8));

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x030507, 0.08);

    const camera = new THREE.PerspectiveCamera(58, window.innerWidth / window.innerHeight, 0.1, 100);
    camera.position.set(0, 0.45, 8.6);

    const group = new THREE.Group();
    scene.add(group);

    const particleCount = window.innerWidth < 700 ? 900 : 1700;
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);
    const palette = [
      new THREE.Color("#4ee6ff"),
      new THREE.Color("#6effb8"),
      new THREE.Color("#ff7272"),
      new THREE.Color("#ffd166"),
      new THREE.Color("#9a84ff")
    ];

    for (let i = 0; i < particleCount; i += 1) {
      const radius = 2.2 + Math.random() * 5.2;
      const angle = Math.random() * Math.PI * 2;
      const arm = Math.sin(i * 0.045) * 0.86;
      positions[i * 3] = Math.cos(angle) * radius + arm;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 4.5;
      positions[i * 3 + 2] = Math.sin(angle) * radius - 4 + Math.random() * 2.3;
      const color = palette[i % palette.length];
      colors[i * 3] = color.r;
      colors[i * 3 + 1] = color.g;
      colors[i * 3 + 2] = color.b;
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({
      size: 0.034,
      vertexColors: true,
      transparent: true,
      opacity: 0.52,
      depthWrite: false,
      blending: THREE.AdditiveBlending
    });

    const points = new THREE.Points(geometry, material);
    group.add(points);

    const ringMaterial = new THREE.MeshBasicMaterial({
      color: 0x4ee6ff,
      transparent: true,
      opacity: 0.13,
      wireframe: true
    });

    for (let i = 0; i < 4; i += 1) {
      const torus = new THREE.Mesh(
        new THREE.TorusGeometry(1.9 + i * 0.75, 0.006, 8, 130),
        ringMaterial.clone()
      );
      torus.rotation.x = Math.PI / 2.8 + i * 0.18;
      torus.rotation.y = i * 0.44;
      torus.position.z = -1.2 - i * 0.2;
      torus.material.opacity = 0.06 + i * 0.018;
      group.add(torus);
    }

    const light = new THREE.PointLight(0x4ee6ff, 14, 26);
    light.position.set(-2, 3, 5);
    scene.add(light);

    const pointer = { x: 0, y: 0 };
    window.addEventListener("pointermove", (event) => {
      pointer.x = (event.clientX / window.innerWidth - 0.5) * 2;
      pointer.y = (event.clientY / window.innerHeight - 0.5) * 2;
    });

    function resize() {
      const width = window.innerWidth;
      const height = window.innerHeight;
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    }

    window.addEventListener("resize", resize);
    resize();

    function animate(now) {
      const time = now * 0.00016;
      points.rotation.y = time * 0.9;
      points.rotation.x = Math.sin(time * 1.6) * 0.16;
      group.rotation.y += (pointer.x * 0.12 - group.rotation.y) * 0.025;
      group.rotation.x += (pointer.y * -0.08 - group.rotation.x) * 0.025;
      group.children.forEach((child, index) => {
        if (child instanceof THREE.Mesh) {
          child.rotation.z = time * (index % 2 ? -1 : 1) * (0.9 + index * 0.08);
        }
      });
      camera.position.x += (pointer.x * 0.28 - camera.position.x) * 0.02;
      camera.position.y += (0.45 + pointer.y * -0.16 - camera.position.y) * 0.02;
      camera.lookAt(0, 0, 0);
      renderer.render(scene, camera);
      requestAnimationFrame(animate);
    }

    requestAnimationFrame(animate);
  } catch (error) {
    drawFallbackScene(canvas, false);
  }
}

function drawFallbackScene(canvas, staticOnly) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  const particles = Array.from({ length: window.innerWidth < 700 ? 90 : 160 }, (_, index) => ({
    x: Math.random(),
    y: Math.random(),
    z: Math.random(),
    hue: index % 5
  }));
  const palette = ["#4ee6ff", "#6effb8", "#ff7272", "#ffd166", "#9a84ff"];

  function resize() {
    canvas.width = Math.floor(window.innerWidth * window.devicePixelRatio);
    canvas.height = Math.floor(window.innerHeight * window.devicePixelRatio);
    canvas.style.width = `${window.innerWidth}px`;
    canvas.style.height = `${window.innerHeight}px`;
    ctx.setTransform(window.devicePixelRatio, 0, 0, window.devicePixelRatio, 0, 0);
  }

  window.addEventListener("resize", resize);
  resize();

  function render(now = 0) {
    const width = window.innerWidth;
    const height = window.innerHeight;
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = "#020304";
    ctx.fillRect(0, 0, width, height);

    particles.forEach((particle, index) => {
      const speed = staticOnly ? 0 : now * 0.000035;
      const angle = particle.x * Math.PI * 2 + speed + index * 0.04;
      const radius = (0.12 + particle.z * 0.48) * Math.min(width, height);
      const x = width * 0.5 + Math.cos(angle) * radius;
      const y = height * 0.48 + Math.sin(angle * 1.35) * radius * 0.42 + (particle.y - 0.5) * 140;
      ctx.beginPath();
      ctx.fillStyle = palette[particle.hue];
      ctx.globalAlpha = 0.18 + particle.z * 0.54;
      ctx.arc(x, y, 1 + particle.z * 2.8, 0, Math.PI * 2);
      ctx.fill();
    });

    ctx.globalAlpha = 0.3;
    ctx.strokeStyle = "#4ee6ff";
    ctx.lineWidth = 1;
    for (let i = 0; i < 5; i += 1) {
      ctx.beginPath();
      ctx.ellipse(width * 0.5, height * 0.5, 140 + i * 76, 46 + i * 21, now * 0.00012 + i, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;

    if (!staticOnly) requestAnimationFrame(render);
  }

  render();
}

function initSkillPlayground() {
  const playground = document.getElementById("skillPlayground");
  const reset = document.getElementById("resetSkills");
  if (!playground) return;

  const tokens = Array.from(playground.querySelectorAll(".skill-token"));
  if (!tokens.length) return;

  const state = new Map();
  let active = null;

  function bounds() {
    return playground.getBoundingClientRect();
  }

  function seed() {
    const rect = bounds();
    tokens.forEach((token, index) => {
      const width = token.offsetWidth || 112;
      const height = token.offsetHeight || 42;
      const columns = Math.max(2, Math.floor(rect.width / 156));
      const row = Math.floor(index / columns);
      const column = index % columns;
      const x = 24 + column * Math.min(156, (rect.width - 120) / columns + 42);
      const y = 96 + row * 76 + (index % 2) * 16;
      const next = {
        x: Math.min(Math.max(18, x), Math.max(18, rect.width - width - 18)),
        y: Math.min(Math.max(76, y), Math.max(76, rect.height - height - 18)),
        vx: ((index % 3) - 1) * 0.45,
        vy: ((index % 4) - 1.5) * 0.35,
        w: width,
        h: height,
        dragging: false,
        lastX: 0,
        lastY: 0,
        lastTime: performance.now()
      };
      state.set(token, next);
      token.style.transform = `translate(${next.x}px, ${next.y}px)`;
    });
  }

  tokens.forEach((token) => {
    token.addEventListener("pointerdown", (event) => {
      const item = state.get(token);
      if (!item) return;
      const rect = bounds();
      token.setPointerCapture(event.pointerId);
      active = token;
      item.dragging = true;
      item.offsetX = event.clientX - rect.left - item.x;
      item.offsetY = event.clientY - rect.top - item.y;
      item.lastX = event.clientX;
      item.lastY = event.clientY;
      item.lastTime = performance.now();
      token.classList.add("is-dragging");
    });

    token.addEventListener("pointermove", (event) => {
      const item = state.get(token);
      if (!item || active !== token || !item.dragging) return;
      const rect = bounds();
      const now = performance.now();
      const delta = Math.max(now - item.lastTime, 16);
      const nextX = event.clientX - rect.left - item.offsetX;
      const nextY = event.clientY - rect.top - item.offsetY;
      item.vx = ((event.clientX - item.lastX) / delta) * 13;
      item.vy = ((event.clientY - item.lastY) / delta) * 13;
      item.x = Math.min(Math.max(6, nextX), rect.width - item.w - 6);
      item.y = Math.min(Math.max(56, nextY), rect.height - item.h - 6);
      item.lastX = event.clientX;
      item.lastY = event.clientY;
      item.lastTime = now;
      token.style.transform = `translate(${item.x}px, ${item.y}px)`;
    });

    function release(event) {
      const item = state.get(token);
      if (!item) return;
      if (token.hasPointerCapture(event.pointerId)) token.releasePointerCapture(event.pointerId);
      item.dragging = false;
      token.classList.remove("is-dragging");
      active = null;
    }

    token.addEventListener("pointerup", release);
    token.addEventListener("pointercancel", release);
  });

  function animate() {
    const rect = bounds();
    tokens.forEach((token) => {
      const item = state.get(token);
      if (!item || item.dragging) return;

      item.x += item.vx;
      item.y += item.vy;
      item.vx *= 0.992;
      item.vy *= 0.992;

      if (item.x <= 6 || item.x + item.w >= rect.width - 6) {
        item.vx *= -0.88;
        item.x = Math.min(Math.max(6, item.x), rect.width - item.w - 6);
      }

      if (item.y <= 56 || item.y + item.h >= rect.height - 6) {
        item.vy *= -0.88;
        item.y = Math.min(Math.max(56, item.y), rect.height - item.h - 6);
      }

      if (Math.abs(item.vx) < 0.06) item.vx += (Math.random() - 0.5) * 0.04;
      if (Math.abs(item.vy) < 0.06) item.vy += (Math.random() - 0.5) * 0.04;

      token.style.transform = `translate(${item.x}px, ${item.y}px)`;
    });
    requestAnimationFrame(animate);
  }

  reset?.addEventListener("click", seed);
  window.addEventListener("resize", seed);

  seed();
  if (!prefersReducedMotion) animate();
}

function initProjectCarousel() {
  const cards = Array.from(document.querySelectorAll(".project-card"));
  const dots = document.getElementById("projectDots");
  const prev = document.getElementById("prevProject");
  const next = document.getElementById("nextProject");
  if (!cards.length || !dots || !prev || !next) return;

  let current = 0;

  cards.forEach((_, index) => {
    const dot = document.createElement("button");
    dot.type = "button";
    dot.setAttribute("aria-label", `Show project ${index + 1}`);
    dot.addEventListener("click", () => setProject(index));
    dots.append(dot);
  });

  const dotButtons = Array.from(dots.querySelectorAll("button"));

  function setProject(index) {
    current = (index + cards.length) % cards.length;
    cards.forEach((card, cardIndex) => {
      card.classList.toggle("active", cardIndex === current);
    });
    dotButtons.forEach((dot, dotIndex) => {
      dot.classList.toggle("active", dotIndex === current);
    });
  }

  prev.addEventListener("click", () => setProject(current - 1));
  next.addEventListener("click", () => setProject(current + 1));
  setProject(0);

  if (!prefersReducedMotion) {
    window.setInterval(() => {
      if (document.hidden) return;
      setProject(current + 1);
    }, 6500);
  }
}

function initContactForm() {
  const form = document.getElementById("contactForm");
  const status = document.getElementById("formStatus");
  if (!(form instanceof HTMLFormElement)) return;

  form.addEventListener("submit", (event) => {
    if (!form.checkValidity()) return;
    if (status) status.textContent = "Sending your message to Sohan...";
  });
}

window.addEventListener("scroll", () => {
  setHeaderState();
  setScrollProgress();
}, { passive: true });

initNavigation();
initReveals();
initCounters();
initCursorGlow();
initTerminal();
initTilt();
initMagneticButtons();
initExperienceModes();
initCaseLab();
initCompanionDock();
initSkillPlayground();
initProjectCarousel();
initContactForm();
setHeaderState();
setScrollProgress();
initThreeScene();
